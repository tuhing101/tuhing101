import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class PART1 {
	public static void main(String args[]) throws Exception {
		Configuration cfg = new Configuration();
		SessionFactory sf = cfg.configure().buildSessionFactory();
		Session ss = sf.openSession();

		MYPOJO3 pj = new MYPOJO3(); // object of mypojo class --> String rollno,name,address;

		String empno, name, phoneno, address;
		Scanner sc = new Scanner(System.in);

		// print all mypojo class data--> return string return "mypojo [rollno=" +
		// rollno + ", name=" + name + ", address=" + address + "]";

		while (true) {
			System.out.println("Select 1 for Inserting");
			System.out.println("Select 2 for Deleting");
			System.out.println("Select 3 for Updating");
			System.out.println("Select 4 for Display");
			System.out.println("Select 5 for Exit");
			int x = sc.nextInt();
			switch (x) {
			case 1:
				Transaction tx = ss.beginTransaction();
				Query q = ss.createQuery("from MYPOJO3"); // query select from mypojo class(table)

				System.out.println("INSERTING VALUES");
				System.out.println("Enter empno");
				empno = sc.next();
				pj.setEmpno(empno);
				System.out.println("Enter name");
				name = sc.next();
				pj.setName(name);
				System.out.println("Enter phoneno");
				phoneno = sc.next();
				pj.setPhoneno(phoneno);
				System.out.println("Enter address");
				address = sc.next();
				pj.setAddress(address);
				ss.save(pj);

				q.setFirstResult(0);
				q.setMaxResults(10);
				List list = q.list();// will return the records from 0 to 10th number
				System.out.println(list);
				tx.commit();
				break;
			case 2:
				Transaction tx1 = ss.beginTransaction();
				System.out.println("Deleting data");
				System.out.println("Enter empoyee id for deleteing ");
				empno = sc.next();
				Query q3 = ss.createQuery("delete from MYPOJO3 where empno=:x");
				q3.setParameter("x", empno);
				q3.executeUpdate();
				System.out.println(empno + " row Deleted");
				tx1.commit();
				break;
			case 3:
				Transaction tx2 = ss.beginTransaction();
				System.out.println("Updating row ");
				System.out.println("Enter emp no for update");
				empno = sc.next();
				System.out.println("Enter name");
				name = sc.next();
				System.out.println("Enter phone no");
				phoneno = sc.next();
				System.out.println("Enter address");
				address = sc.next();

				Query q4 = ss.createQuery("update MYPOJO3 set name=:n, phoneno=:p, address=:ad where empno=:e");
				q4.setParameter("n", name);
				q4.setParameter("p", phoneno);
				q4.setParameter("ad", address);
				q4.setParameter("e", empno);

				int status1 = q4.executeUpdate();
				System.out.println(empno + "row updated " + status1);
				tx2.commit();
				break;
			case 4:

				Query q5 = ss.createQuery("from MYPOJO3");
				q5.setFirstResult(0);
				q5.setMaxResults(10);
				List stud1 = q5.list();
				System.out.println(stud1);
				Iterator it1 = stud1.iterator();
				while (it1.hasNext()) {
					pj = (MYPOJO3) it1.next();
					System.out.println("Display Last Entry");
					System.out.println(pj.getEmpno());
					System.out.println(pj.getName());
					System.out.println(pj.getPhoneno());
					System.out.println(pj.getAddress());
				}
				break;
			case 5:
				System.exit(x);
				break;

			}

		}

//		pojo2.setId("2");
//		pojo2.setName("mahesh");
//		pojo2.setAge("23");
//		pojo2.setAddress("bhilai");
//		pojo2.setContact("232323");
//		ss.save(pojo2); //insert data in table pojo2

//		Query q5 = ss.createQuery("from mypojo2");
//		q5.setFirstResult(0);  
//		q5.setMaxResults(10); 
//		List stud3 = q5.list();
//		System.out.println(stud3);
//		
//		
//		List stud=q.list();
//		Iterator it=stud.iterator();
//		while(it.hasNext())
//		{
//			pojo=(mypojo)it.next();
//			System.out.println(pojo.getRollno());
//			System.out.println(pojo.getName());
//			System.out.println(pojo.getAddress());
//		}

//		Query q1=ss.createQuery("from mypojo1");
//		q1.setFirstResult(0);  
//		q1.setMaxResults(10);
//		List stud1=q1.list();
//		System.out.println(stud1);
//		Iterator it1=stud1.iterator();
//		while(it1.hasNext())
//		{
//			pojo1=(mypojo1)it1.next();
//			System.out.println(pojo1.getPhoneno());
//			System.out.println(pojo1.getEmail());
//			System.out.println(pojo1.getPassword());
//		}

//		Query q2=ss.createQuery("update mypojo set name=:n, address=:a where rollno=:i"); 
//		//we use pojo class name not the table name
//		
//		q2.setParameter("n","ram");  
//		q2.setParameter("a","hyderabad");
//		q2.setParameter("i","101");  
//		  
//		
//		int status=q2.executeUpdate();  
//		System.out.println(status); 
//		
//		Query q3=ss.createQuery("update mypojo1 set email=:n, password=:a where phoneno=:i"); 
//		q3.setParameter("n","max@gmail.com");  
//		q3.setParameter("a","1111");
//		q3.setParameter("i","99887766");  
//	 
//		int status1=q3.executeUpdate();  
//		System.out.println(status1); 

//		
//		Query q3=ss.createQuery("delete from mypojo where rollno='101' ");  
//		//specifying class name (mypojo) not tablename  
//		int status1=q3.executeUpdate();
//		System.out.println(status1);  

//		 

//		Query q4=ss.createQuery("select count(rollno) from mypojo");  
//		System.out.println(q4);

	}
}

/*
 * create table details1(phoneno varchar2(30),email varchar2(30),password
 * varchar2(30));
 * 
 * insert into details1 values('99887766','sandip@gmail.com','1234')
 * 
 * create table details(rollno varchar2(30),name varchar2(30),address
 * varchar2(30));
 * 
 * insert into details values('101','sandip','bangalore')
 */